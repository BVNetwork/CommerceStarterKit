﻿define("epi-ecf-ui/contentediting/viewmodel/_RelationCollectionEditorModelMixin", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/topic",
    "dojo/when",
// epi
    "epi/shell/command/DelegateCommand",
// epi cms
    "epi-cms/dgrid/formatters",
// epi-ecf-ui
    "epi-ecf-ui/contentediting/_HasNotificationMixin",
// Resources
    "epi/i18n!epi/nls/episerver.shared"
], function (
//dojo
    array,
    declare,
    topic,
    when,
// epi
    DelegateCommand,
// epi cms
    formatters,
// epi-ecf-ui
    _HasNotificationMixin,
// Resources
    sharedResources
) {

    return declare([_HasNotificationMixin], {

        // module:
        //      epi-ecf-ui/contentediting/viewmodel/_RelationCollectionEditorModelMixin
        // summary:
        //      Mixes in overrides of CollectionEditorModel, which can be used by a relation collection editor model to get save, move, remove functionality etz.

        resources: null,

        setSortOrderOnChange: true,

        postscript: function(){
            this.inherited(arguments);

            this.own(topic.subscribe("relationChanged", this._refresh.bind(this)));
        },

        generateColumnsDefinition: function () {
            // summary:
            //      Generate columns definition.
            // tags:
            //      public

            return {
                contentTypeIdentifier: {
                    label: "",
                    className: "epi-columnIcon16x16",
                    formatter: function (typeIdentifier, additionalClass) {
                        return formatters.contentIcon(typeIdentifier, additionalClass);
                    }
                },
                name: {
                    label: this.resources.headings.name
                },
                path: {
                    label: this.resources.headings.path
                }
            };
        },

        getItemCommands: function() {
            var commands = this.inherited(arguments);

            if (commands) {
                for (var i = 0; i < commands.length; i++) {
                    if (commands[i].name === "remove") {
                        commands[i].iconClass = "epi-iconClose";
                    }
                }
            }

            return commands;
        },

        getListCommands: function (availableCommands) {

            return [
                new DelegateCommand({
                    name: "add",
                    label: this.resources.addlabel,
                    tooltip: sharedResources.action.add,
                    iconClass: "epi-iconPlus",
                    canExecute: true,
                    isAvailable: true,
                    delegate: this.addItemDelegate.bind(this)
                })
            ];
        },


        addItem: function (item, refItem, before) {
            var items = this.get("items");
            if (items && items.length > 0) {
                // check if adding item is existed, to move it to above
                // instead of adding duplicated item.
                var itemIdentifier = item.permanentUrl || item.target;
                var existingItem;
                array.some(items, function (oldItem) {
                    if (oldItem && oldItem.target === itemIdentifier) {
                        existingItem = oldItem;
                        return true;
                    }
                });

                if (existingItem) {
                    this.moveItem(existingItem, refItem || existingItem, before || true);
                    return this._refresh();
                }
            }

            if (this.setSortOrderOnChange) {
                // Set sort order before inherited to avoid including new items sort order in calculation
                this._setSortOrder(item, refItem, before);
            }

            return when(this.inherited(arguments), function () {
                return when(this._store.add(item), this._refresh.bind(this), function (error) {
                    return this._showNotification(error, this._refresh.bind(this));
                }.bind(this));
            }.bind(this));
        },

        moveItem: function (item, refItem, before) {
            return when(this.inherited(arguments), function () {
                if (this.setSortOrderOnChange) {
                    this._setSortOrder(item, refItem, before);
                }
                return when(this._store.put(item), this._refresh.bind(this), function (error) {
                    return this._showNotification(error, this._refresh.bind(this));
                }.bind(this));
            }.bind(this));
        },

        removeItem: function (item) {
            return when(this.inherited(arguments), function () {
                return when(this._store.remove(item.id), this._refresh.bind(this), function (error) {
                    return this._showNotification(error, this._refresh.bind(this));
                }.bind(this));
            }.bind(this));
        },

        saveItem: function (item, index) {
            return when(this.inherited(arguments), function () {
                return when(this._store.put(item), this._refresh.bind(this), function (error) {
                    return this._showNotification(error, this._refresh.bind(this));
                }.bind(this));
            }.bind(this));
        },

        _refresh: function () {
            // This will force a refresh of the grid.
            this.set("data", this.get("data"));
        },

        _setSortOrder: function(item, refItem, before) {
            if (refItem) {
                // Set sortOrder equal to refItem to place it before
                // The store will update sort index of any items after it
                item.sortOrder = before ? refItem.sortOrder : refItem.sortOrder + 1;
            } else {
                // Place last
                var items = this.get("items");
                var lastSortOrder = (items.length > 0) ? items[items.length - 1].sortOrder : 0;
                if (!item.sortOrder || lastSortOrder >= item.sortOrder) {
                    item.sortOrder = lastSortOrder + 100;
                }
            }
        }
    });
});