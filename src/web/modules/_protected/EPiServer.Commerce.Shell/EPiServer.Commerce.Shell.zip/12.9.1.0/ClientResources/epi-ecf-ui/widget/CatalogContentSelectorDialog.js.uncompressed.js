﻿define("epi-ecf-ui/widget/CatalogContentSelectorDialog", [
    // dojo
    "dojo/_base/declare",
    // epi
    "epi-cms/widget/ContentSelectorDialog",
    "epi-ecf-ui/widget/_CatalogContentSelectorTreeMixin"
], function (
    // dojo
    declare,
    // epi
    ContentSelectorDialog,
    _CatalogContentSelectorTreeMixin
) {
        return declare([ContentSelectorDialog, _CatalogContentSelectorTreeMixin], {
            buildRendering: function () {
                this.inherited(arguments);
                this._setupContentSelectorTree(this.tree);
            }
        });
    });