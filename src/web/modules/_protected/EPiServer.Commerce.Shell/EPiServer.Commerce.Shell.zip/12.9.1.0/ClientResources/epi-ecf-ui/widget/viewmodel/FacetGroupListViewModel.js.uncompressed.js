﻿define("epi-ecf-ui/widget/viewmodel/FacetGroupListViewModel", [
// dojo
    "dojo/_base/declare",

    "dojo/Stateful",
    "dojo/when",
//dijit
    "dijit/Destroyable",
// epi
    "epi",
    "epi/dependency"
], function (
// dojo
    declare,

    Stateful,
    when,
//dijit
    Destroyable,
// epi
    epi,
    dependency
) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      View model for "FacetGroupList" widget.
        // tags:
        //      public

        // facetGroups: [public] Array
        //      The collection of facet group.
        facetGroups: [],

        _hashFacetFiltersGetter: function () {
            // summary:
            //      Gets latest facet filters information from URL.
            // returns: [Array]
            //      Collection of object in { id: [string], values: [Array] } format.
            // tags:
            //      protected

            return this._facetFiltersService.getFilters();
        },

        contentStoreKeyName: "epi.cms.content.light",

        postscript: function () {
            this.inherited(arguments);

            this._facetFiltersService = this._facetFiltersService || dependency.resolve("epi.commerce.FacetFiltersService");

            var registry = dependency.resolve("epi.storeregistry");
            this.contentStore = this.contentStore || registry.get(this.contentStoreKeyName);
            this._setupOnStoreItemDeleted();
        },

        fetchData: function () {
            // summary:
            //      Gets facets data.
            // tags:
            //      public

            when(this._getData(), function (facet) {
                if (!facet || !facet.groups) {
                    return;
                }

                this.set("facetGroups", facet.groups);
            }.bind(this));
        },

        fetchRecalculatedData: function () {
            // summary:
            //      Gets facets data with recalculated total numbers.
            // tags:
            //      public

            when(this._getData(), function (facet) {
                if (!facet || !facet.groups) {
                    return;
                }

                var items = {};
                facet.groups.forEach(function (group) {
                    items[group.id] = group.items;
                });

                this.set("facetGroupsItems", items);
            }.bind(this));
        },

        updateFacetFilter: function (key, values) {
            // summary:
            //      Updates facet filter with the given key and values.
            // key: [string]
            //      Facet filter key.
            // values: [Array]
            //      Facet filter values.
            // tags:
            //      public

            var facetFilters = this.get("facetFilters"),
                keyIndex = -1;

            facetFilters.forEach(function (item, index) {
                if (item.id === key) {
                    keyIndex = index;
                    return;
                }
            });

            // Delete existing filter if the group do not have values.
            if (values.every(function (item) { return !item; })) {
                if (keyIndex !== -1) {
                    facetFilters.splice(keyIndex, 1);
                }

                return;
            }

            if (keyIndex !== -1) {
                // Update existing group setting.
                facetFilters[keyIndex].values = values;
            } else {
                // Add new setting
                facetFilters.push({
                    "id": key,
                    values: values
                });
            }
        },

        refreshHashFacetFilters: function () {
            // summary:
            //      Updates latest facet filters to URL.
            // tags:
            //      public

            var newFilters = this._facetFiltersService.filtersToHash(this.get("facetFilters"));
            this._facetFiltersService.updateFilters(newFilters);
        },

        _setupOnStoreItemDeleted: function () {
            if (epi.isEmpty(this.contentStore)) {
                return;
            }

            this.own(
                this.contentStore.on("delete", function (deletedItem) {
                    var deleted = !epi.isEmpty(deletedItem && deletedItem.id);
                    deleted && this.fetchRecalculatedData();
                }.bind(this))
            );
        },

        _getData: function () {
            // summary:
            //      Gets facets data.
            //      Should implements this function in concrete class in order to returns data that fetched from server.
            // tags:
            //      protected, extensions
        }

    });

});