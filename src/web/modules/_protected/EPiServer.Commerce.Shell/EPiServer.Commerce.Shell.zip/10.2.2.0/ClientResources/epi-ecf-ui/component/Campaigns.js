//>>built
define("epi-ecf-ui/component/Campaigns",["dojo/_base/declare","epi-cms/widget/HierarchicalList"],function(_1,_2){return _1([_2],{setupContextMenu:function(){}});});