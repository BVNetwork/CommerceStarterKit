require({cache:{
'url:epi-ecf-ui/widget/templates/_MarketingListBase.html':"﻿<div>\r\n    <!-- the toolbar is only here to be able to resize without exceptions -->\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"dijit/_WidgetBase\" style=\"display:none\"></div>\r\n    <div data-dojo-attach-point=\"gridNode\"></div>\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/DefaultColumnHeader.html':"﻿<div>\r\n    <h1>${headingLabel}</h1>\r\n    <h2>${subheadingLabel}</h2>\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/DatePeriodColumnHeader.html':"﻿<h1>${headingLabel}</h1>\r\n<h2>${fromDate} - ${toDate}</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionNameColumn.html':"﻿<div>\r\n    <h3>${headingLabel}</h3>\r\n    <span class=\"dijitInline dijitReset dijitIcon epi-objectIcon ${iconClass}\"></span> <span class=\"epi-secondaryText\">${subheadingLabel}</span>\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionStatusColumn.html':"﻿<div class=\"epi-grid-column--centered\">\r\n    ${text} ${date}\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/RedemptionsColumn.html':"﻿<div class=\"epi-grid-column--centered\">\r\n    ${redemptions}\r\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/TotalOrderColumn.html':"﻿<div class=\"epi-grid-column--centered\">\r\n    <h3>${totalCount}</h3>\r\n    <span class=\"epi-secondaryText\">${totalCaption}</span>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/_MarketingListBase", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/string",
    "dojo/when",
// dijit
    "dgrid/tree",
// epi
    "epi/datetime",
    "epi/shell/dgrid/util/misc",
    "epi/shell/TypeDescriptorManager",
// epi-cms
    "epi-cms/widget/_ConfigurableContentListBase",
// epi-ecf-ui
    "../MarketingUtils",
    "./_GridRowStatusMixin",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "dojo/text!./templates/_MarketingListBase.html",
    "dojo/text!./viewmodel/templates/DefaultColumnHeader.html",
    "dojo/text!./viewmodel/templates/DatePeriodColumnHeader.html",
    "dojo/text!./viewmodel/templates/PromotionNameColumn.html",
    "dojo/text!./viewmodel/templates/PromotionStatusColumn.html",
    "dojo/text!./viewmodel/templates/RedemptionsColumn.html",
    "dojo/text!./viewmodel/templates/TotalOrderColumn.html"
], function (
// dojo
    declare,
    lang,
    domClass,
    domConstruct,
    dojoString,
    when,
//dijit
    tree,
// epi
    epiDate,
    shellMisc,
    TypeDescriptorManager,
// epi-cms
    _ConfigurableContentListBase,
// epi-ecf-ui
    MarketingUtils,
    _GridRowStatusMixin,
// resources
    resources,
    templateString,
    defaultColumnHeaderTemplate,
    datePeriodColumnHeaderTemplate,
    promotionNameColumnTemplate,
    promotionStatusColumnTemplate,
    redemptionsColumnTemplate,
    totalOrderColumnTemplate
) {
    return declare([_ConfigurableContentListBase, _GridRowStatusMixin], {
        // summary:
        //      Represents the widget to support to styling a grid to display marketing item
        // tags:
        //      public

        templateString: templateString,

        storeKeyName: "epi.cms.content.light",

        // queryName: string
        //      Default query is get children
        queryName: "getchildren",

        _campaignClassName: "epi-card-grid__heading",

        _promotionClassName: "epi-card-grid__content",

        getQuery: function (parentId) {
            return {
                query: this.queryName,
                referenceId: parentId,
                typeIdentifiers: this.typeIdentifiers
            };
        },

        startup: function () {
            this.inherited(arguments);

            when(this.getCurrentContext()).then(lang.hitch(this, function (currentContext) {
                this.grid.set("query", this.getQuery(currentContext.id));
            }));
        },

        onContextChanged: function (context) {
            // Refresh list after edit
            this.grid.set("query", this.getQuery(context.id));
        },

        getListSettings: function () {
            var settings = this.inherited(arguments);

            return lang.mixin(this.defaultGridMixin, lang.mixin(settings, {
                className: "epi-card-grid",
                store: this.store,
                selectionMode: "none",
                cellNavigation: false,
                noDataMessage: resources.emptycampaign
            }));
        },

        getItemClass: function (item) {
            //  Override mixin class

            if (MarketingUtils.isSalesCampaign(item.typeIdentifier)) {
                return this._campaignClassName;
            } else {
                return this._promotionClassName;
            }
        },

        getItemModifier: function (item) {
            if (item.properties.status === MarketingUtils.status.expired) {
                return MarketingUtils.isSalesCampaign(item.typeIdentifier) ?
                            this.status[MarketingUtils.status.expired] :
                            this.status[MarketingUtils.status.inactive];
            } else {
                return this.inherited(arguments);
            }
        },

        getColumnSettings: function(){
            return {
                expando: tree({
                    label: "",
                    sortable: false,
                    shouldExpand: function () { return true; },
                    renderExpando: function (level, hasChildren, expanded, object) {
                        // summary:
                        //      We override the default expando rendering to get rid of the
                        //      default indentation.

                        var node = domConstruct.create("div");
                        //"dgrid-expando-icon" is needed for click events
                        domClass.add(node, "dgrid-expando-icon");
                        node.innerHTML = "&nbsp;";
                        return node;
                    }
                }),
                name: {
                    className: "epi-grid--40",
                    get: lang.hitch(this.model, this.model._getNameModel),
                    formatter: lang.hitch(this, this._getNameHtml)
                },
                status: {
                    className: "epi-grid-column--centered",
                    get: lang.hitch(this.model, this.model._getStatusModel),
                    formatter: lang.hitch(this, this._getStatusHtml)
                },
                ordertotal: {
                    className: "epi-grid-column--centered",
                    get: lang.hitch(this.model, this.model._getTotalOrderModel),
                    formatter: lang.hitch(this, this._getTotalOrderHtml)
                },
                redemptions: {
                    className: "epi-grid--15 epi-grid-column--centered",
                    get: lang.hitch(this.model, this.model._getStatusModel),
                    formatter: lang.hitch(this, this._getRedemptionHtml)
                },
                revenue: {
                    className: "epi-grid--15",
                    get: function (campaignItem) {
                        return { typeIdentifier: campaignItem.typeIdentifier, revenue: campaignItem.properties.redeemedValue };
                    },
                    renderCell: lang.hitch(this, function (item, value, node, options) {
                        domClass.add(node, "epi-grid-column--centered");
                        node.innerHTML = "&nbsp;"; //TODO: Add column value when is implemented on the server
                    })
                }
            };
        },

        _getTotalOrderHtml: function (model) {
            if (model.isSalesCampaign) {
                return dojoString.substitute(defaultColumnHeaderTemplate, {
                    headingLabel: model.count,
                    subheadingLabel: resources.totalorders
                });
            }
            return dojoString.substitute(totalOrderColumnTemplate, {
                totalCount: model.count,
                totalCaption: resources.orders
            });
        },

        _getRedemptionHtml: function (statusColumnModel) {
            if (MarketingUtils.isSalesCampaign(statusColumnModel.typeIdentifier)) {
                return dojoString.substitute(defaultColumnHeaderTemplate, {
                    headingLabel: resources.redemptions,
                    subheadingLabel: "&nbsp;"
                });
            }

            return dojoString.substitute(redemptionsColumnTemplate, {
                redemptions: statusColumnModel.redemptions || ""
            });
        },

        _getStatusHtml: function (statusColumnModel) {
            if (MarketingUtils.isSalesCampaign(statusColumnModel.typeIdentifier)) {
                return dojoString.substitute(datePeriodColumnHeaderTemplate, {
                    headingLabel: resources.status[statusColumnModel.statusLabelKey],
                    fromDate: epiDate.toUserFriendlyString(statusColumnModel.validFrom, null, null, true),
                    toDate: epiDate.toUserFriendlyString(statusColumnModel.validUntil, null, null, true)
                });
            }

            var promotionStatus = statusColumnModel.status;
            var campaignStatus = statusColumnModel.campaignStatus;

            if (promotionStatus === MarketingUtils.status.inactive) {
                return resources.status.inactive;
            }

            if (statusColumnModel.followsCampaignSchedule || campaignStatus === MarketingUtils.status.expired || campaignStatus === MarketingUtils.status.inactive) {
                return "";
            }

            if (promotionStatus === MarketingUtils.status.active) {
                return dojoString.substitute(promotionStatusColumnTemplate, {
                    text: epiDate.toUserFriendlyString(statusColumnModel.validFrom, null, null, true) + " -",
                    date: epiDate.toUserFriendlyString(statusColumnModel.validUntil, null, null, true)
                });
            }

            return dojoString.substitute(promotionStatusColumnTemplate, {
                date: epiDate.toUserFriendlyString(this._getDate(statusColumnModel), null, null, true),
                text: this._getDateText(statusColumnModel)
            });
        },

        _getDate: function (statusColumnModel) {

            if (statusColumnModel.validFrom > new Date()) {
                return statusColumnModel.validFrom;
            }

            return statusColumnModel.validUntil;
        },

        _getDateText: function (statusColumnModel) {
            var validFrom = statusColumnModel.validFrom,
                validUntil = statusColumnModel.validUntil,
                now = new Date();

            if (validFrom < now && validUntil > now) { // Currently active
                return resources.datetext.active;
            }

            if (validFrom > now) { // Pending
                return resources.datetext.pending;
            }

            return resources.datetext.expired; // Expired
        },

        _getNameHtml: function (nameColumnModel) {
            var template = promotionNameColumnTemplate;

            if (MarketingUtils.isSalesCampaign(nameColumnModel.typeIdentifier)) {
                template = defaultColumnHeaderTemplate;
            }

            return dojoString.substitute(template, {
                headingLabel: shellMisc.htmlEncode(nameColumnModel.name),
                subheadingLabel: (!!nameColumnModel.group) ? resources.group[nameColumnModel.group] : resources.campaign,
                iconClass: TypeDescriptorManager.getValue(nameColumnModel.typeIdentifier, "iconClass")
            });
        }
    });
});