﻿define("epi-ecf-ui/widget/NewInventory", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "epi/shell/widget/FormContainer",
    "../contentediting/editors/_KeyboardBlurMixin"
], function (
    array,
    declare,
    FormContainer,
    _KeyboardBlurMixin
){
    return declare([FormContainer, _KeyboardBlurMixin], {
        _setMetadataAttr: function (value) {
            // summary:
            //      Sets metadata for this widget.

            array.some(value.properties, function (property) {
                if (property.name === "WarehouseCode") {
                    property.settings.readOnly = false; // Make the location field writable.  
                    return true;
                }
            });

            this.metadata = value;
        }
    });
});