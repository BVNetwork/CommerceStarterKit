﻿define("epi-ecf-ui/widget/CampaignItemList", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/_base/lang",
    "dojo/keys",
    "dojo/when",
// epi
    "epi/shell/command/builder/ButtonBuilder",
// commerce
    "./viewmodel/CampaignItemListModel",
    "../MarketingUtils",
    "./_MarketingListBase",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist"
],
function (
// dojo
    declare,
    event,
    lang,
    keys,
    when,
// epi
    ButtonBuilder,
// commerce
    CampaignItemListModel,
    MarketingUtils,
    _MarketingListBase,
// resources
    resources
) {
    return declare([_MarketingListBase], {

        typeIdentifiers: [
            MarketingUtils.contentTypeIdentifier.salesCampaign,
            MarketingUtils.contentTypeIdentifier.promotionData
        ],

        withDeleteButton: false,

        buildRendering: function () {
            // summary:
            //		Construct the UI for this widget with this.domNode initialized as a dgrid.
            // tags:
            //		protected

            this.inherited(arguments);

            this._modifyStoreToHandleDgridTree();
        },

        createModel: function () {
            return new CampaignItemListModel({
                store: this.store
            });
        },

        getListSettings: function() {
            var settings = this.inherited(arguments);
            if (this.withDeleteButton){
                this._replaceContextMenuByDeleteButton(settings.columns);
            }

            var self = this;
            return lang.mixin(this.defaultGridMixin, lang.mixin(settings, {
                dndDisabled: true,
                showHeader: false,
                renderArray: function(){
                    return when(this.inherited(arguments), lang.hitch(this, function(trs){
                        //After calling the inherited renderArray function we clear the noDataNode.
                        //This forces the grid to create a new node every time a campaign does not have any promotion.
                        this.noDataNode = null;
                        return trs;
                    }));
                },
                onContextMenuClick: function(e){
                    this.inherited(arguments);
                    self.onContextMenuClick(e);
                }
            }));
        },

        setupEvents: function(){
            this.inherited(arguments);
            this.grid.addKeyHandler(keys.DELETE, lang.hitch(this, function(e){
                var row = this.grid.row(e);
                var deleteCommand = this.model.createDeleteCommand();
                deleteCommand.set("model", row.data);
                deleteCommand.execute();
            }));
        },

        _modifyStoreToHandleDgridTree: function(){
            // summary:
            //      getChildren and mayHaveChildren are needed on the store
            //      for dgrids tree module to work.
            // tags:
            //      private
            var self = this;
            this.store = lang.mixin(this.store, {
                getChildren: function (parent, options) {
                    return this.query(self._getQuery(parent.contentLink), options);
                },
                mayHaveChildren: function (parent) {
                    // only campaigns have children
                    return MarketingUtils.isSalesCampaign(parent.typeIdentifier);
                }
            });
        },

        onContextMenuClick: function(e) {
            this.inherited(arguments);
            var row = this.grid.row(e);
            this.model.updateCommandModel(row.data);
        },

        _replaceContextMenuByDeleteButton: function(columnSettings){
            columnSettings = lang.mixin(columnSettings, {
                contextMenu : {
                    renderHeaderCell: function () { }, // no header
                    renderCell: lang.hitch(this, function (object, value, node, options) {
                        var deleteCommand = this.model.createDeleteCommand(false);
                        var builder = new ButtonBuilder({
                            settings: {
                                showLabel: false,
                                "class": "epi-chromeless",
                                onKeyDown: function(e){
                                    if (e.keyCode === keys.ENTER){
                                        //when pressing ENTER on button
                                        //we need to stop the grids key
                                        //handler changing context.
                                        event.stop(e);
                                    }
                                }
                            }
                        });
                        deleteCommand.set("model", object);
                        builder.create(deleteCommand, node);
                    }),
                    className: "epi-columnNarrow",
                    sortable: false
                }
            });
        }
    });
});