﻿define("epi-ecf-ui/contentediting/editors/CategoryCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",

    // epi commerce
    "./ReadOnlyCollectionEditor",
    "../viewmodel/CategoryCollectionReadOnlyEditorModel",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.categorycollectioneditor"
],
function (
    //dojo
    declare,
    
    // epi commerce
    ReadOnlyCollectionEditor,
    CategoryCollectionReadOnlyEditorModel,

    res
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/RelationCollectionEditor
        // summary:
        //      Represents the Read-only editor widget for product's inventory list.

        iconClass: "epi-iconCategory",

        modelType: CategoryCollectionReadOnlyEditorModel,

        _renderNoDataMessage: function () {
            this.grid.set("noDataMessage", res.nodatamessage);
            this.inherited(arguments);
        },
               
        changeToView: "linksview",

        buttonLabel: res.editbuttontext
    });
});