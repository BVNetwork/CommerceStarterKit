﻿define("epi-ecf-ui/widget/_GridRowStatusMixin", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class"
], function (
// dojo
    declare,
    lang,
    aspect,
    domClass
) {
    return declare([], {
        // summary:
        //      A custom class name for grid row, based on row's status 
        // tags:
        //      public

        // prefixClassName: string
        //      The prefix class name to set on grid row
        prefixClassName: "",

        // status: Object
        //      Indicated status of content
        status: {
            "0": "",
            "1": "active",
            "2": "pending",
            "3": "expired",
            "4": "inactive"
        },

        postCreate: function () {
            this.inherited(arguments);

            if (!this.grid) {
                throw new Error("The _GridRowStatusMixin should be mixed to a widget that has a grid");
            }
        },

        setupEvents: function () {
            // summary:
            //      Initialization of events on the list.
            // tags:
            //      protected, extension
            this.inherited(arguments);
            this.own(aspect.around(this.grid, "renderRow", lang.hitch(this, this._aroundRenderRow)));
        },

        _aroundRenderRow: function (original) {
            // summary:
            //      Called 'around' the renderRow method in order to add a class which indicates the state of the row
            // tags:
            //      private

            return lang.hitch(this, function (item) {
                // Call original method
                var row = original.apply(this.grid, arguments);

                if (item) {
                    domClass.add(row, [ this.getItemClass(item), this.getItemStatusClass(item) ]);
                }

                return row;
            });
        },

        getItemClass: function (item) {
            // summary:
            //      Gets the content CSS class name.
            // tags:
            //      protected, extension
            return this.prefixClassName;
        },

        getItemStatusClass: function (item) {
            // summary:
            //      Gets the status CSS class name of content
            // tags:
            //      protected, extension
            return this.getItemClass(item) + "--" + this.getItemModifier(item);
        },

        getItemModifier: function (item) {
            // summary:
            //      Gets the modifier CSS class name of content
            // tags:
            //      protected, extension
            return this.status[this.getItemStatus(item)];
        },

        getItemStatus: function (item) {
            // summary:
            //      Gets the status of content
            // tags:
            //      protected, extension
            return item.properties.status;
        }
    });
});