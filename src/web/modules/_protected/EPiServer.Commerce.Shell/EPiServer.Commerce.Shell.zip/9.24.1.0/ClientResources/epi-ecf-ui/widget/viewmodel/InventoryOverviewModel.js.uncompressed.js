﻿define("epi-ecf-ui/widget/viewmodel/InventoryOverviewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/Stateful",

    // EPi Framework
    "epi/dependency",
    "epi/datetime",
    "epi/shell/_StatefulGetterSetterMixin"
], function (
// dojo
    declare,
    lang,
    when,
    Stateful,
    // EPi Framework
    dependency,
    epiDate,
    _StatefulGetterSetterMixin
) {
    return declare([Stateful, _StatefulGetterSetterMixin], {
        // summary:
        //    Represents the inventory overview widget's model.
        // model:
        //    "epi-ecf-ui/widget/viewmodel/InventoryOverviewModel"
        // tags:
        //    public

        _contentStructureStore: null,

        content: null,

        postscript: function () {
            // summary:
            //      Post properties mixin handler.
            // description:
            //      Set up model and resource for template binding.
            // tags:
            //      protected

            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._contentStructureStore = this._contentStructureStore || registry.get("epi.cms.content.light");
        },

        populateData: function () {
            // summary:
            //      Loads data.
            // tags:
            //      protected
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.

            this._set("value", value);

            when(this._contentStructureStore.get(value), lang.hitch(this, function (content) {
                this.set("content", content);
            }));
        },

        getDefaultItem: function () {
            // summary:
            //      Get default inventory of the current content data.
            // tags:
            //      protected

            return {
                preorderQuantity: 0,
                reorderMinQuantity: 0,
                additionalQuantity: 0,
                backorderAvailableQuantity: 0
            };
        }
    });
});
