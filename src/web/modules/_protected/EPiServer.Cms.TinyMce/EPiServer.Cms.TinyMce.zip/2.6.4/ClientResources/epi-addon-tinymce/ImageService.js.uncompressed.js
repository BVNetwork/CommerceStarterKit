define("epi-addon-tinymce/ImageService", [
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/when",

    "epi/dependency",
    "epi-cms/widget/_HierarchicalModelMixin",
    "epi-cms/contentediting/_ContextualContentContextMixin",
    "epi-cms/core/PermanentLinkHelper"
], function (
    declare,
    Deferred,
    when,

    dependency,
    _HierarchicalModelMixin,
    _ContextualContentContextMixin,
    PermanentLinkHelper
) {
    var HierarchicalModelClass = declare([_HierarchicalModelMixin, _ContextualContentContextMixin]);

    var createDefaultHierarchicalModel = function () {
        var store = dependency.resolve("epi.storeregistry").get("epi.cms.content.light");
        return new HierarchicalModelClass({ store: store });
    };

    function ImageService(hierarchicalModel, permanentLinkHelper) {
        // summary:
        //      A service for interacting with images in epi-addon-tinymce.
        // tags:
        //      internal
        this.hierarchicalModel = hierarchicalModel || createDefaultHierarchicalModel();
        this.permanentLinkHelper = permanentLinkHelper || PermanentLinkHelper;
    }

    // hierarchicalModel: [readonly] Object
    //      A model that can get the ancestors of an image
    ImageService.prototype.hierarchicalModel = null;

    // permanentLinkHelper: [readonly] epi-cms/core/PermanentLinkHelper
    //      A permanent link helper to get an Episerver image content from the url to an image.
    ImageService.prototype.permanentLinkHelper = null;

    ImageService.prototype.getImageContentFromUrl = function (url) {
        // summary:
        //      Gets an image content from the specified url.
        // tags:
        //      internal
        var deferred = new Deferred();

        when(this.permanentLinkHelper.getContent(url)).then(function (content) {
            return content ? deferred.resolve(content) : deferred.reject();
        });
        return deferred.promise;
    };

    ImageService.prototype.getPathToImage = function (image) {
        // summary:
        //      Resolves a path to the supplied image by looking up its ancestors and returning the first root.
        // tags:
        //      internal

        var deferred = new Deferred();

        try {
            this.hierarchicalModel.getAncestors(image, function (ancestors) {

                var filteredAncestors = [];
                for (var index = ancestors.length - 1; index >= 0; index--) {
                    filteredAncestors.unshift(ancestors[index]);
                    if (this.hierarchicalModel.isTypeOfRoot(ancestors[index])) {
                        break;
                    }
                }

                filteredAncestors.push(image);

                var ancestorNames = filteredAncestors.map(function (ancestor) {
                    return ancestor.name;
                });

                // If there are more than 4 ancestors replace the ones in the middle with ...
                if (ancestorNames.length > 4) {
                    ancestorNames = ancestorNames.slice(0, 2).concat("...", ancestorNames.slice(-2));
                }

                deferred.resolve(ancestorNames.join(" > "));
            }.bind(this));
        } catch (error) {
            deferred.reject(error);
        }

        return deferred.promise;
    };

    return ImageService;
});
