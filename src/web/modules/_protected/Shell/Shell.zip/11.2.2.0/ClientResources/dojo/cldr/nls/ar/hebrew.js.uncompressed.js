define(
"dojo/cldr/nls/ar/hebrew", //begin v1.x content
{
	"dateFormatItem-yM": "M/yyyy",
	"dateFormatItem-yQ": "Q yyyy",
	"dayPeriods-format-wide-pm": "م",
	"eraNames": [
		"ص"
	],
	"dateFormatItem-MMMEd": "E، d MMM",
	"dateFormatItem-yQQQ": "QQQ y",
	"days-standAlone-wide": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"dayPeriods-format-wide-am": "ص",
	"timeFormat-full": "h:mm:ss a zzzz",
	"months-standAlone-abbr": [
		"تشري",
		"مرحشوان",
		"كيسلو",
		"طيفت",
		"شباط",
		"آذار الأول",
		"آذار",
		"نيسان",
		"أيار",
		"سيفان",
		"تموز",
		"آب",
		"أيلول"
	],
	"dateFormatItem-Ed": "E، d",
	"dateFormatItem-yMMM": "MMM y",
	"days-standAlone-narrow": [
		"ح",
		"ن",
		"ث",
		"ر",
		"خ",
		"ج",
		"س"
	],
	"eraAbbr": [
		"ص"
	],
	"dateFormat-long": "d MMMM، y",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormat-medium": "dd/MM/yyyy",
	"dateFormatItem-yMd": "d/M/yyyy",
	"quarters-standAlone-narrow": [
		"١",
		"٢",
		"٣",
		"٤"
	],
	"months-standAlone-wide": [
		"تشري",
		"مرحشوان",
		"كيسلو",
		"طيفت",
		"شباط",
		"آذار الأول",
		"آذار",
		"نيسان",
		"أيار",
		"سيفان",
		"تموز",
		"آب",
		"أيلول"
	],
	"dateFormatItem-MMMd": "d MMM",
	"quarters-format-narrow": [
		"١",
		"٢",
		"٣",
		"٤"
	],
	"timeFormat-long": "h:mm:ss a z",
	"months-format-abbr": [
		"تشري",
		"مرحشوان",
		"كيسلو",
		"طيفت",
		"شباط",
		"آذار الأول",
		"آذار",
		"نيسان",
		"أيار",
		"سيفان",
		"تموز",
		"آب",
		"أيلول"
	],
	"timeFormat-short": "h:mm a",
	"days-format-abbr": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"dateFormatItem-yMMMd": "d MMM، y",
	"dateFormatItem-MEd": "E، d/M",
	"days-standAlone-short": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"days-standAlone-abbr": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"dateFormat-short": "d/M/yyyy",
	"dateFormatItem-yMMMEd": "E، d MMM، y",
	"dateFormat-full": "EEEE، d MMMM، y",
	"dateFormatItem-Md": "d/M",
	"dateFormatItem-yMEd": "E، d/M/yyyy",
	"months-format-wide": [
		"تشري",
		"مرحشوان",
		"كيسلو",
		"طيفت",
		"شباط",
		"آذار الأول",
		"آذار",
		"نيسان",
		"أيار",
		"سيفان",
		"تموز",
		"آب",
		"أيلول"
	],
	"days-format-short": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"quarters-format-wide": [
		"الربع الأول",
		"الربع الثاني",
		"الربع الثالث",
		"الربع الرابع"
	],
	"months-format-wide-leap": "آذار الثاني",
	"eraNarrow": [
		"ص"
	],
	"days-format-wide": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	]
}
//end v1.x content
);